package org.openmrs.module.basicmodule.dsscompiler;

import org.openmrs.module.basicmodule.dsscompiler.ast.AST;
import org.openmrs.module.basicmodule.dsscompiler.interpreter.DSSLibrary;
import org.openmrs.module.basicmodule.dsscompiler.interpreter.Interpreter;
import org.openmrs.module.basicmodule.dsscompiler.parser.Parser;

/**
 * Used as a convenience to run DSS programs.
 * 
 * @author woeltjen
 */
public class DSSRunner {
    
    /**
     * Run the DSS program specified in the provided file. Optionally, 
     * additional intrinsic functions may be provided as DSSLibrary objects; 
     * these will be installed in the interpreter's execution context before 
     * the program is run.
     * @param filename the name of the DSS
     * @param libraries any libraries to pre-install
     * @throws Exception when file cannot be found or parsed
     */
    public static void runDSSProgram(String filename, DSSLibrary... libraries) 
        throws Exception {
        runDSSProgram(new Parser(filename).execute(), libraries);
    }
    
    /**
     * Run a DSS program (that has already been parsed). Optionally, 
     * additional intrinsic functions may be provided as DSSLibrary objects; 
     * these will be installed in the interpreter's execution context before 
     * @param tree the DSS1 program
     * @param libraries any libraries to pre-install
     */
    public static void runDSSProgram(AST tree, DSSLibrary... libraries) {
        Interpreter interpreter = new Interpreter();
        
        // Install any supplied libraries of intrinsic functions
        for (DSSLibrary lib : libraries) {
            interpreter.install(lib);
        }
        
        interpreter.interpret(tree);
    }
}
