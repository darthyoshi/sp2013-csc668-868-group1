package org.openmrs.module.basicmodule.dsscompiler.intrinsics;

import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;

/**
 *
 * @author woeltjen
 */
@Retention(value=RetentionPolicy.RUNTIME)
public @interface DSSIdentifier {
    
}
