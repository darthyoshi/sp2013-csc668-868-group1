package org.openmrs.module.basicmodule.dsscompiler.intrinsics;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;
import org.openmrs.ConceptDatatype;
import org.openmrs.Encounter;
import org.openmrs.Obs;
import org.openmrs.api.EncounterService;
import org.openmrs.api.context.Context;
import org.openmrs.module.basicmodule.dsscompiler.value.DSSValue;
import org.openmrs.module.basicmodule.dsscompiler.value.DSSValueFactory;

/**
 *
 * @author woeltjen
 */
public class AnnotatedReadLibrary extends AnnotatedDSSLibrary {
        @DSSIntrinsic
    public List<DSSValue> readInitialEncounter (int patientId, @DSSIdentifier String conceptName) {
        return read(patientId, conceptName, ReadType.INITIAL); 
    }

    @DSSIntrinsic
    public List<DSSValue> readLatestEncounter (int patientId, @DSSIdentifier String conceptName) {
        return read(patientId, conceptName, ReadType.LATEST);
    }
    
    @DSSIntrinsic
    public List<DSSValue> read (int patientId, @DSSIdentifier String conceptName) {
        return read(patientId, conceptName, ReadType.ALL);
    }

    
    private DSSValue toDSSValue(Obs obs) {
        DSSValue v;

        Date obsTime = obs.getObsDatetime();
        if (obsTime == null) {
            obsTime = obs.getDateCreated();
        }
        
        ConceptDatatype dataType = obs.getConcept().getDatatype();
        if (dataType.isBoolean()) {
            v = DSSValueFactory.getDSSValue(obs.getValueAsBoolean());
        } else if (dataType.isDate() || dataType.isDateTime()) {
            v = DSSValueFactory.getDSSValue(obs.getValueDatetime());            
        } else if (dataType.isNumeric()) {
            v = DSSValueFactory.getDSSValue(obs.getValueNumeric());
        } else {
            v = DSSValueFactory.getDSSValue(obs.getValueText());
        }
        
        v.setTimeStamp(obsTime);
        
        return v;
    }
    
    private List<DSSValue> toDSSValues(List<Encounter> encounters, String conceptName) {
        List<DSSValue> results = new ArrayList<DSSValue>();

        for (Encounter e : encounters) {
            if (!e.isVoided()) {
                Set<Obs> obses = e.getAllObs();
                for (Obs obs : obses) {
                    if (!obs.isVoided() && 
                            obs.getConcept().getName().equals(conceptName)) {
                        results.add(toDSSValue(obs));
                    }
                }
            }
        }
        return results;        
    }
    

    public List<DSSValue> read (int patientId, 
            @DSSIdentifier String conceptName, ReadType readType) {
        EncounterService encounterService = Context.getEncounterService();
       
        List<Encounter> encounters = 
                encounterService.getEncountersByPatientId(patientId);
        
        if (encounters.size() > 0) {
            switch(readType) {
                case INITIAL:
                    encounters = Arrays.asList(encounters.get(0));
                case LATEST:
                    encounters = Arrays.asList(encounters.get(encounters.size() - 1));
            }
        }

        return toDSSValues(encounters, conceptName);
    }
    
    private static enum ReadType {
        INITIAL,
        LATEST,
        ALL
    }
}
