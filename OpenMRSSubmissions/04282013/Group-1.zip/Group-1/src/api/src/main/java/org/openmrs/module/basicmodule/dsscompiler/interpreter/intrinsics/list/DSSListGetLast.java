/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package org.openmrs.module.basicmodule.dsscompiler.interpreter.intrinsics.list;

/**
 *
 * @author openmrs
 */
public class DSSListGetLast {
    
}
