package org.openmrs.module.basicmodule.dsscompiler.intrinsics;

import org.openmrs.module.basicmodule.dsscompiler.value.DSSValue;

/**
 *
 * @author woeltjen
 */
public class MiscLibrary extends AnnotatedDSSLibrary {
    @DSSIntrinsic
    public int length(DSSValue v) {
        return v.length();
    }
    
    @DSSIntrinsic
    public boolean within(DSSValue v, DSSValue a, DSSValue b) {
        return v.greaterthanequal(a) && v.lessthanequal(b);
    }
}
