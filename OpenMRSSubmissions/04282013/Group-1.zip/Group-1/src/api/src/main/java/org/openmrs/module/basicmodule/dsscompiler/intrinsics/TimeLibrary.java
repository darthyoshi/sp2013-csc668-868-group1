package org.openmrs.module.basicmodule.dsscompiler.intrinsics;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import org.openmrs.module.basicmodule.dsscompiler.value.DSSValue;
import org.openmrs.module.basicmodule.dsscompiler.value.DSSValueFactory;

/**
 *
 * @author woeltjen
 */
public class TimeLibrary extends AnnotatedDSSLibrary {
    private static final long MS_PER_DAY = 1000L * 60L * 60L * 24L;
    
    @DSSIntrinsic
    public Date currenttime() {
        return new Date(); // Date defaults to current time
    }
    
    @DSSIntrinsic
    public DSSValue recentTimeItem(List<DSSValue> values) {
        DSSValue recent = DSSValueFactory.getDSSValue();
        for (DSSValue value : values) {
            if (recent.isNull() || 
                value.getDSSValueTimeStamp().greaterthan(recent.getDSSValueTimeStamp())) {
                recent = value;
            }
        }
        return recent;
    }
    
    @DSSIntrinsic
    public DSSValue oldestTimeItem(List<DSSValue> values) {
        DSSValue recent = DSSValueFactory.getDSSValue();
        for (DSSValue value : values) {
            if (recent.isNull() || 
                value.getDSSValueTimeStamp().lessthan(recent.getDSSValueTimeStamp())) {
                recent = value;
            }
        }
        return recent;
    }

    @DSSIntrinsic
    public boolean before(Date a, Date b) {
        return a.getTime() < b.getTime();
    }
    
    @DSSIntrinsic
    public DSSValue time (DSSValue v) {
        return v.getDSSValueTimeStamp();
    }

    @DSSIntrinsic
    public Date addDays(Date time,  int days) {
        return new Date(time.getTime() + days * MS_PER_DAY);
    }
    
    @DSSIntrinsic
    public Date addMonths(Date time,  int months) {
        Calendar cal = new GregorianCalendar();
        cal.setTimeInMillis(time.getTime());
        cal.add(Calendar.MONTH, months);
        return cal.getTime();
    }
}
